
$(document).ready(function () {
  $('.image-popup-vertical-fit').magnificPopup({
    type: 'image',
    mainClass: 'mfp-with-zoom',
    gallery: {
      enabled: true
    },

    zoom: {
      enabled: true,

      duration: 300, // duration of the effect, in milliseconds
      easing: 'ease-in-out', // CSS transition easing function

      opener: function (openerElement) {

        return openerElement.is('img') ? openerElement : openerElement.find('img');
      }
    }

  });

});
 
const multipleItemCarousel = document.querySelector("#TeamcarouselExampleControls");

if (window.matchMedia("(min-width:400px)").matches) {
  const carousel = new bootstrap.Carousel(multipleItemCarousel, {
    interval: false
  });

  var carouselWidth = $(".team.carousel-inner")[0].scrollWidth;
  var cardWidth = $(".team.carousel-item").width();

  var scrollPosition = 0;

  $(".team.carousel-control-next").on("click", function () {
    if (scrollPosition < carouselWidth - cardWidth * 4) {
      scrollPosition = scrollPosition + cardWidth;
      $(".team.carousel-inner").animate({ scrollLeft: scrollPosition }, 600);
    }
  });
  $(".team.carousel-control-prev").on("click", function () {
    if (scrollPosition > 0) {
      scrollPosition = scrollPosition - cardWidth;
      $(".team.carousel-inner").animate({ scrollLeft: scrollPosition }, 600);
    }
  });
} else {
  $(multipleItemCarousel).addClass("slide");
}



$(".copy-btn").click(function (event) {
  event.stopPropagation(); // Prevent the click from affecting the parent div
  let parentDiv = $(this).closest(".content-div"); // Get the closest parent with the class "content-div"
  let innerHtml = parentDiv.find(".htmlcode").html(); // Get the HTML of the <pre> tag inside the parent div

  // Copy to clipboard
  navigator.clipboard.writeText(innerHtml)
    .then(() => {
      alert("Copied!");
      $("#output").text("Copied to Clipboard: " + innerHtml); // Show confirmation
    })
    .catch(err => {
      alert("Failed to copy: ", err);
      $("#output").text("Failed to copy!");
    });
});
 
$(document).ready(function() {
$('.popup-gallery').magnificPopup({
delegate: 'a',
type: 'image',
tLoading: 'Loading image #%curr%...',
mainClass: 'mfp-img-mobile',
gallery: {
enabled: true,
navigateByImgClick: true,
preload: [0,1] // Will preload 0 - before current, and 1 after the current image
},
image: {
tError: '<a href="%url%">The image #%curr%</a> could not be loaded.',
titleSrc: function(item) {
return item.el.attr('title') + '<small>by Marsel Van Oosten</small>';
}
}
});
});
 
 document.querySelector('.navbar-toggler').addEventListener('click', function() { 
  var icon = this.querySelector('.navbar-toggler-icon'); 
  icon.classList.toggle('hamburger');
  icon.classList.toggle('close'); 
});  

