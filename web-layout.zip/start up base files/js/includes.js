$(document).ready(function() {  
    
    $("#Navbars").load("includes/Navbars.html");
    $("#solid-nav-01").load("includes/solid-nav-01.html");
    $("#solid-nav-02").load("includes/solid-nav-02.html");
    $("#solid-nav-03").load("includes/solid-nav-03.html");
    $("#solid-nav-04").load("includes/solid-nav-04.html");

    $("#transparent-nav-01").load("includes/transparent-nav-01.html");
    $("#transparent-nav-02").load("includes/transparent-nav-02.html");
    $("#transparent-nav-03").load("includes/transparent-nav-03.html");
    $("#transparent-nav-04").load("includes/transparent-nav-04.html");

    $("#blured-nav-01").load("includes/blured-nav-01.html");
    $("#blured-nav-02").load("includes/blured-nav-02.html");
    $("#blured-nav-03").load("includes/blured-nav-03.html");
    $("#blured-nav-04").load("includes/blured-nav-04.html");   

    $("#hero-section-01").load("includes/hero-section-01.html"); 
    $("#hero-section-02").load("includes/hero-section-02.html");   
    $("#hero-section-03").load("includes/hero-section-03.html"); 
    $("#hero-section-04").load("includes/hero-section-04.html");      
    
});